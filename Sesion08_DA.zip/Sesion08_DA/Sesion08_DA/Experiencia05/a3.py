def file_read(fname):
    with open (fname, "r") as myfile:
        data=myfile.readlines()
        print(data)
file_read('test.txt')

""""

El código proporcionado define una función llamada file_read que toma un parámetro fname, 
que se supone que es el nombre de un archivo. 
Luego, la función abre el archivo en modo de lectura ("r"), 
lee todas las líneas del archivo utilizando el método readlines(), 
y luego imprime esas líneas en la salida estándar.
Cuando ejecutas esta aplicación con file_read('test.txt'), 
el programa intentará abrir el archivo "test.txt" en modo de lectura, 
leer todas las líneas del archivo y mostrar esas líneas en la pantalla.

"""""
