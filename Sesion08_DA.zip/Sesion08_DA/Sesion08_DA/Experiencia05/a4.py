import glob
char_list = []
files_list = glob.glob("*.txt")
for file_elem in files_list:
    with open(file_elem, "r") as f:
        char_list.append(f.read())
print(char_list)

#Este programa busca archivos con la extensión ".txt" en el directorio actual, 
#lee su contenido y almacena ese contenido en una lista. 
#La salida del programa será una lista que contiene el contenido de todos los archivos ".txt" 
#encontrados en el directorio.
