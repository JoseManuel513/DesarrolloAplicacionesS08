#b) CREAR UN ARCHIVO TIPO BINARIO:
# Nombre del archivo
nombre_archivo_binario = "archivo_binario.dat"

# Abrir el archivo en modo escritura binaria
archivo_binario = open(nombre_archivo_binario, "wb")

# Escribir contenido binario en el archivo (puedes usar bytes)
datos_binarios = bytes([65, 66, 67, 68, 69])  # Ejemplo de datos binarios
archivo_binario.write(datos_binarios)
archivo_binario.close()
