# a) CREAR UN ARCHIVO TIPO TEXTO:
# Nombre del archivo
nombre_archivo = "archivo_texto.txt"

# Abrir el archivo en modo escritura de texto
archivo = open(nombre_archivo, "w")
archivo.write("Este es un archivo de texto.\n")
archivo.write("Puedes agregar más contenido aquí.\n")

archivo.close()
