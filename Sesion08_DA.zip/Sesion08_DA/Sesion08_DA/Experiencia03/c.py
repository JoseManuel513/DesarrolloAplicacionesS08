#c) ABRIR UN ARCHIVO PARA ESCRITURA:
# Nombre del archivo existente
nombre_archivo_existente = "archivo_existente.txt"

# Abrir el archivo en modo escritura de texto
archivo_existente = open(nombre_archivo_existente, "w")

# Escribir contenido en el archivo (esto sobrescribirá el contenido existente)
archivo_existente.write("Este es el nuevo contenido del archivo.\n")
archivo_existente.close()
