class Estudiante:
    def __new__(cls, nombre="", edad=0):
        instance = super(Estudiante, cls).__new__(cls)
        return instance

    def __init__(self, nombre="", edad=0):
        self.nombre = nombre
        self.edad = edad
        self.matriculado = False
        self.deuda_pension = 0

    def ingresarDatos(self):
        self.nombre = input("Ingrese el nombre del estudiante: ")
        self.edad = int(input("Ingrese la edad del estudiante: "))

    def matricular(self):
        self.matriculado = True
        self.deuda_pension = 1000

    def pagarPension(self, monto):
        if self.matriculado:
            if monto >= self.deuda_pension:
                self.deuda_pension = 0
                print("La deuda de pensión ha sido saldada.")
            else:
                self.deuda_pension -= monto
                print(f"Se han abonado ${monto} a la deuda de pensión.")
        else:
            print("El estudiante no está matriculado.")

    def imprimirDatos(self):
        print(f"Nombre: {self.nombre}")
        print(f"Edad: {self.edad}")
        print(f"Matriculado: {self.matriculado}")
        print(f"Deuda de pensión: ${self.deuda_pension}")
