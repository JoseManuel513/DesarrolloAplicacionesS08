from estudiante import Estudiante

def main():
    estudiante = Estudiante("Juan", 22)

    estudiante.matricular()
    estudiante.pagarPension(500)
    
    print("Datos del estudiante:")
    estudiante.imprimirDatos()

if __name__ == "__main__":
    main()
