class Estudiante:
    def __init__(self):
        self._nombre = ""
        self._edad = 0
        self._matriculado = False
        self._deuda_pension = 0

    @property
    def nombre(self):
        return self._nombre

    @nombre.setter
    def nombre(self, valor):
        self._nombre = valor

    @property
    def edad(self):
        return self._edad

    @edad.setter
    def edad(self, valor):
        self._edad = valor

    @property
    def matriculado(self):
        return self._matriculado

    @property
    def deuda_pension(self):
        return self._deuda_pension

    def matricular(self):
        self._matriculado = True
        self._deuda_pension = 1000  # Supongamos una deuda de pensión inicial de $1000.

    def pagarPension(self, monto):
        if self._matriculado:
            if monto >= self._deuda_pension:
                self._deuda_pension = 0
                print("La deuda de pensión ha sido saldada.")
            else:
                self._deuda_pension -= monto
                print(f"Se han abonado ${monto} a la deuda de pensión.")
        else:
            print("El estudiante no está matriculado.")
