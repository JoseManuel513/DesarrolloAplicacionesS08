from estudiante import Estudiante

def main():
    estudiante = Estudiante()
    
    print("Bienvenido al sistema de gestión de estudiantes.")
    estudiante.nombre = "Juan"  # Accede y establece la propiedad nombre.
    estudiante.edad = 20  # Accede y establece la propiedad edad.

    # Ejecuta los métodos utilizando las propiedades.
    estudiante.matricular()
    estudiante.pagarPension(500)
    
    print(f"Nombre: {estudiante.nombre}")  # Accede a la propiedad nombre.
    print(f"Edad: {estudiante.edad}")  # Accede a la propiedad edad.
    print(f"Matriculado: {estudiante.matriculado}")  # Accede a la propiedad matriculado.
    print(f"Deuda de pensión: {estudiante.deuda_pension}")  # Accede a la propiedad deuda_pension.

if __name__ == "__main__":
    main()
