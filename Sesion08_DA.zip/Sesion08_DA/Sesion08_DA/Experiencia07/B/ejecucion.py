from estudiante import Estudiante

def main():
    # ... (crear un objeto estudiante y realizar otras operaciones)

    # Ejecutar el método de clase obtener_edad_maxima
    edad_maxima = Estudiante.obtener_edad_maxima()
    print(f"Edad máxima permitida para estudiantes: {edad_maxima} años")

    # Validar un nombre utilizando el método de clase validar_nombre
    nombre = "Ejemplo de un nombre largo que excede los 30 caracteres"
    if Estudiante.validar_nombre(nombre):
        print(f"El nombre '{nombre}' es válido.")
    else:
        print(f"El nombre '{nombre}' excede la longitud máxima permitida.")

if __name__ == "__main__":
    main()
