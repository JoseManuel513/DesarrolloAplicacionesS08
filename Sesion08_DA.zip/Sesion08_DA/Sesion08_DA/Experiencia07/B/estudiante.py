class Estudiante:
    # ... (propiedades y otros métodos)

    @classmethod
    def obtener_edad_maxima(cls):
        return 30  # Supongamos una edad máxima de 30 años para los estudiantes.

    @classmethod
    def validar_nombre(cls, nombre):
        return len(nombre) <= 30  # Supongamos que los nombres no pueden exceder los 30 caracteres.
