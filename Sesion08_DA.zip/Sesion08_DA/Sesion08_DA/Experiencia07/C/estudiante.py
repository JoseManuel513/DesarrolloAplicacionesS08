class Estudiante:
    # ... (propiedades y otros métodos)

    @staticmethod
    def calcular_promedio(notas):
        return sum(notas) / len(notas)

    @staticmethod
    def validar_edad(edad):
        return 18 <= edad <= 30  # Supongamos que las edades válidas están entre 18 y 30 años.
