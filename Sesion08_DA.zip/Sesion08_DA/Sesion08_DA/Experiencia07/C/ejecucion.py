from estudiante import Estudiante

def main():
    # Ejecutar el método estático calcular_promedio
    notas = [85, 90, 78, 92, 88]
    promedio = Estudiante.calcular_promedio(notas)
    print(f"Promedio de notas: {promedio}")

    # Validar una edad utilizando el método estático validar_edad
    edad = 25
    if Estudiante.validar_edad(edad):
        print(f"La edad {edad} es válida.")
    else:
        print(f"La edad {edad} no está dentro del rango válido.")

if __name__ == "__main__":
    main()
