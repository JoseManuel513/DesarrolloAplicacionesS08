from estudiante import Estudiante

def main():
    estudiante = Estudiante()
    while True:
        print("\nMenu:")
        print("1. Ingresar datos del estudiante")
        print("2. Imprimir datos del estudiante")
        print("3. Matricular al estudiante")
        print("4. Pagar pensión")
        print("5. Salir")
        opcion = input("Seleccione una opción: ")

        if opcion == "1":
            estudiante.ingresarDatos()
        elif opcion == "2":
            estudiante.imprimirDatos()
        elif opcion == "3":
            estudiante.matricular()
        elif opcion == "4":
            monto = int(input("Ingrese el monto a pagar: "))
            estudiante.pagarPension(monto)
        elif opcion == "5":
            break
        else:
            print("Opción no válida. Intente nuevamente.")

if __name__ == "__main__":
    main()
