from estudiante import Estudiante

# Crear objetos de instancia de la clase Estudiante y almacenarlos en una lista.
estudiantes = []
estudiante1 = Estudiante()
estudiante2 = Estudiante()
estudiantes.append(estudiante1)
estudiantes.append(estudiante2)

# Ingresar datos para cada estudiante.
for estudiante in estudiantes:
    estudiante.ingresarDatos()

# Ejecutar los métodos para cada estudiante.
for estudiante in estudiantes:
    estudiante.imprimirDatos()

# Matricular a los estudiantes.
for estudiante in estudiantes:
    estudiante.matricular()

# Pagar la pensión para cada estudiante.
for estudiante in estudiantes:
    monto = int(input("Ingrese el monto a pagar para el estudiante: "))
    estudiante.pagarPension(monto)

# Imprimir los datos actualizados de cada estudiante.
for estudiante in estudiantes:
    estudiante.imprimirDatos()
