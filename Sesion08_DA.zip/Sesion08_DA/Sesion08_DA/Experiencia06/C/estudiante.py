class Estudiante:
    def __init__(self):
        self.nombre = ""
        self.edad = 0
        self.matriculado = False
        self.deuda_pension = 0

    def ingresarDatos(self):
        self.nombre = input("Nombre del estudiante: ")
        self.edad = int(input("Edad del estudiante: "))

    def imprimirDatos(self):
        print(f"Nombre: {self.nombre}")
        print(f"Edad: {self.edad}")
        if self.matriculado:
            print("Matriculado: Sí")
            print(f"Deuda de pensión: ${self.deuda_pension}")
        else:
            print("Matriculado: No")

    def matricular(self):
        self.matriculado = True
        self.deuda_pension = 1000  # Supongamos una deuda de pensión inicial de $1000.

    def pagarPension(self, monto):
        if self.matriculado:
            if monto >= self.deuda_pension:
                self.deuda_pension = 0
                print("La deuda de pensión ha sido saldada.")
            else:
                self.deuda_pension -= monto
                print(f"Se han abonado ${monto} a la deuda de pensión.")
        else:
            print("El estudiante no está matriculado.")

# Ejemplo de uso de la clase
if __name__ == "__main__":
    estudiante = Estudiante()
    estudiante.ingresarDatos()