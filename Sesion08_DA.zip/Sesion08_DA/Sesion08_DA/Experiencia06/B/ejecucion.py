from estudiante import Estudiante

def main():
    estudiante = Estudiante()
    
    print("Bienvenido al sistema de gestión de estudiantes.")
    estudiante.ingresarDatos()
    
    while True:
        print("\nMenu:")
        print("1. Imprimir datos del estudiante")
        print("2. Matricular al estudiante")
        print("3. Pagar pensión")
        print("4. Salir")
        opcion = input("Seleccione una opción: ")

        if opcion == "1":
            estudiante.imprimirDatos()
        elif opcion == "2":
            estudiante.matricular()
            print("El estudiante ha sido matriculado.")
        elif opcion == "3":
            monto = int(input("Ingrese el monto a pagar: "))
            estudiante.pagarPension(monto)
        elif opcion == "4":
            print("Gracias por utilizar el sistema.")
            break
        else:
            print("Opción no válida. Intente nuevamente.")

if __name__ == "__main__":
    main()
