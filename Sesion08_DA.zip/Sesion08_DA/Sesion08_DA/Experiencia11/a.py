import sqlite3

# Establecer una conexión a la base de datos 'orders.db'
conn = sqlite3.connect('orders.db')

# Crear un objeto cursor para ejecutar consultas SQL
cur = conn.cursor()

# Crear la tabla 'orders' si no existe
cur.execute("""
CREATE TABLE IF NOT EXISTS orders (
    ORDERID INT,
    DATE TEXT,
    USERID INT,
    TOTAL REAL
);
""")

# Imprimir un mensaje para confirmar que la base de datos se abrió con éxito
print("Base de datos abierta satisfactoriamente")

# Insertar un solo registro en la tabla 'orders' usando un parámetro
order = (5, '15/06/2015', 3, 400215)
cur.execute("INSERT INTO orders VALUES (?, ?, ?, ?);", order)

# Confirmar los cambios realizados en la base de datos
conn.commit()

# Imprimir un mensaje para confirmar que el registro se creó satisfactoriamente
print("Registro creado satisfactoriamente")

# Crear una lista de tuplas con más registros a insertar
moreOrders = [(6, '03/10/2021', 3, 2015478), (7, '02/01/2019', 3, 2015698)]

# Insertar múltiples registros en la tabla 'orders' usando 'executemany'
cur.executemany("INSERT INTO orders VALUES (?, ?, ?, ?);", moreOrders)

# Confirmar los cambios realizados en la base de datos
conn.commit()

# Imprimir un mensaje para confirmar que los registros se crearon satisfactoriamente
print("Registros creados satisfactoriamente")

# Cerrar la conexión a la base de datos
conn.close()
