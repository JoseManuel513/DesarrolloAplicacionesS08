import sqlite3

# Establecer una conexión a la base de datos 'orders.db'
conn = sqlite3.connect('orders.db')

# Imprimir un mensaje para confirmar que la base de datos se abrió con éxito
print("Base de datos abierta satisfactoriamente")

# Crear un objeto cursor para ejecutar consultas SQL
cur = conn.cursor()

# Crear la tabla 'users' si no existe
cur.execute("""
CREATE TABLE IF NOT EXISTS users (
    userid INT,
    fname TEXT,
    lname TEXT,
    gender TEXT
);
""")

# Crear la tabla 'orders' si no existe
cur.execute("""
CREATE TABLE IF NOT EXISTS orders (
    orderid INT,
    date TEXT,
    userid INT,
    total REAL
);
""")

# Ejecutar una consulta SQL que une las tablas 'orders' y 'users' utilizando LEFT JOIN
cur.execute("""
SELECT orders.*, users.fname, users.lname
FROM orders
LEFT JOIN users ON users.userid = orders.userid;
""")

# Usar fetchall() para recuperar todos los resultados de la consulta
results = cur.fetchall()

# Imprimir los resultados
for result in results:
    print(result)

# Imprimir un mensaje para confirmar que la consulta se realizó satisfactoriamente
print("Consulta realizada satisfactoriamente")

# Cerrar la conexión a la base de datos
conn.close()