import sqlite3

# Establecer una conexión a la base de datos 'orders.db'
conn = sqlite3.connect('orders.db')

# Imprimir un mensaje para confirmar que la base de datos se abrió con éxito
print("Base de datos abierta satisfactoriamente")

# Crear un objeto cursor para ejecutar consultas SQL
cur = conn.cursor()

# Ejecutar una consulta SQL para seleccionar todos los registros de la tabla 'orders'
cur.execute("SELECT * FROM orders;")

# Usar fetchall() para recuperar todos los resultados
all_results = cur.fetchall()

# Imprimir los resultados
print(all_results)

# Imprimir un mensaje para confirmar que la consulta se realizó satisfactoriamente
print("Consulta realizada satisfactoriamente")

# Cerrar la conexión a la base de datos
conn.close()
