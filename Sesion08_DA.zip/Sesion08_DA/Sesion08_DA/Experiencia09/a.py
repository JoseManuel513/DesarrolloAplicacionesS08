import sqlite3

# Crear una conexión a la base de datos o una base de datos en memoria
conn = sqlite3.connect('pedidos.db')

# Crear un objeto cursor para ejecutar consultas SQL
cur = conn.cursor()

# Crear una tabla en la base de datos
cur.execute('''
    CREATE TABLE IF NOT EXISTS pedidos (
        id INTEGER PRIMARY KEY,
        producto TEXT,
        cantidad INTEGER,
        precio REAL
    )
''')

# Insertar datos en la tabla
cur.execute("INSERT INTO pedidos (producto, cantidad, precio) VALUES (?, ?, ?)", ("Producto A", 10, 15.99))
cur.execute("INSERT INTO pedidos (producto, cantidad, precio) VALUES (?, ?, ?)", ("Producto B", 5, 12.49))

# Guardar los cambios en la base de datos
conn.commit()

# Consultar los datos en la tabla
cur.execute("SELECT * FROM pedidos")
rows = cur.fetchall()

# Imprimir los resultados
for row in rows:
    print(row)

# Cerrar el cursor y la conexión
cur.close()
conn.close()
