class Producto:
    def __init__(self, codigo, nombre, precio):
        self.codigo = codigo
        self.nombre = nombre
        self.precio = precio

    def __str__(self):
        return f"Código: {self.codigo}, Nombre: {self.nombre}, Precio: {self.precio}"


class Cliente:
    def __init__(self, id_cliente, nombre, email):
        self.id_cliente = id_cliente
        self.nombre = nombre
        self.email = email

    def __str__(self):
        return f"ID Cliente: {self.id_cliente}, Nombre: {self.nombre}, Email: {self.email}"


class Venta:
    def __init__(self, cliente, productos):
        self.cliente = cliente
        self.productos = productos

    def agregar_producto(self, producto, cantidad):
        self.productos.append({"producto": producto, "cantidad": cantidad})

    def calcular_total(self):
        total = sum(item["producto"].precio * item["cantidad"] for item in self.productos)
        return total

    def __str__(self):
        return f"Cliente: {self.cliente}\nProductos:\n{', '.join([str(item['producto']) for item in self.productos])}\nTotal: {self.calcular_total()}"


# Listas para almacenar los objetos
productos_registrados = []
clientes_registrados = []
ventas_registradas = []

while True:
    print("Seleccione una opción:")
    print("1. Registrar Producto")
    print("2. Registrar Cliente")
    print("3. Realizar Venta")
    print("4. Salir")
    
    opcion = input("Opción: ")

    if opcion == "1":
        codigo_producto = input("Ingrese el código del producto: ")
        nombre_producto = input("Ingrese el nombre del producto: ")
        precio_producto = float(input("Ingrese el precio del producto: "))
        producto = Producto(codigo_producto, nombre_producto, precio_producto)
        productos_registrados.append(producto)
        print("Producto registrado con éxito.")

    elif opcion == "2":
        id_cliente = int(input("Ingrese el ID del cliente: "))
        nombre_cliente = input("Ingrese el nombre del cliente: ")
        email_cliente = input("Ingrese el email del cliente: ")
        cliente = Cliente(id_cliente, nombre_cliente, email_cliente)
        clientes_registrados.append(cliente)
        print("Cliente registrado con éxito.")

    elif opcion == "3":
        if not clientes_registrados or not productos_registrados:
            print("Registre al menos un cliente y un producto antes de realizar una venta.")
            continue

        # Seleccione un cliente
        print("Seleccione un cliente:")
        for i, cliente in enumerate(clientes_registrados):
            print(f"{i + 1}. {cliente}")
        seleccion_cliente = int(input("Cliente (número): ") ) - 1

        # Cree una venta
        cliente_seleccionado = clientes_registrados[seleccion_cliente]
        venta_actual = Venta(cliente_seleccionado, [])
        
        while True:
            # Seleccione un producto
            print("Seleccione un producto:")
            for i, producto in enumerate(productos_registrados):
                print(f"{i + 1}. {producto}")
            seleccion_producto = int(input("Producto (número): ") ) - 1
            
            producto_seleccionado = productos_registrados[seleccion_producto]
            cantidad = int(input("Cantidad: "))
            
            venta_actual.agregar_producto(producto_seleccionado, cantidad)
            
            continuar = input("¿Agregar otro producto? (S/N): ").strip().lower()
            if continuar != "s":
                break
        
        ventas_registradas.append(venta_actual)
        print("Venta registrada con éxito.")
    
    elif opcion == "4":
        print("Saliendo del programa.")
        break
    else:
        print("Opción no válida. Por favor, elija una opción válida.")
