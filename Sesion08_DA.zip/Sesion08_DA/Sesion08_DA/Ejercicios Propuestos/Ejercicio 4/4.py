def buscar_reemplazar_texto(archivo, buscar, reemplazar):
    try:
        with open(archivo, "r") as file:
            contenido = file.read()
        
        nuevo_contenido = contenido.replace(buscar, reemplazar)
        
        with open(archivo, "w") as file:
            file.write(nuevo_contenido)
        
        print(f"Se ha reemplazado '{buscar}' con '{reemplazar}' en el archivo '{archivo}'.")
    except FileNotFoundError:
        print(f"El archivo '{archivo}' no se encontró.")

# Nombre del archivo en el que deseas buscar y reemplazar texto
nombre_archivo = "mi_archivo.txt"

cadena_a_buscar = "texto_a_buscar"
cadena_a_reemplazar = "nuevo_texto"

# Llama a la función para buscar y reemplazar
buscar_reemplazar_texto(nombre_archivo, cadena_a_buscar, cadena_a_reemplazar)
