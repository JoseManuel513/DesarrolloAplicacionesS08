class Producto:
    def __init__(self, codigo, nombre, precio):
        self.codigo = codigo
        self.nombre = nombre
        self.precio = precio

    def __str__(self):
        return f"Código: {self.codigo}, Nombre: {self.nombre}, Precio: {self.precio}"


class Cliente:
    def __init__(self, id_cliente, nombre, email):
        self.id_cliente = id_cliente
        self.nombre = nombre
        self.email = email

    def __str__(self):
        return f"ID Cliente: {self.id_cliente}, Nombre: {self.nombre}, Email: {self.email}"


class Venta:
    def __init__(self, cliente, productos):
        self.cliente = cliente
        self.productos = productos

    def agregar_producto(self, producto, cantidad):
        self.productos.append({"producto": producto, "cantidad": cantidad})

    def calcular_total(self):
        total = sum(item["producto"].precio * item["cantidad"] for item in self.productos)
        return total

    def __str__(self):
        return f"Cliente: {self.cliente}\nProductos:\n{', '.join([str(item['producto']) for item in self.productos])}\nTotal: {self.calcular_total()}"


# Ingresar datos del producto
codigo_producto = input("Ingrese el código del producto: ")
nombre_producto = input("Ingrese el nombre del producto: ")
precio_producto = float(input("Ingrese el precio del producto: "))

producto = Producto(codigo_producto, nombre_producto, precio_producto)

# Ingresar datos del cliente
id_cliente = int(input("Ingrese el ID del cliente: "))
nombre_cliente = input("Ingrese el nombre del cliente: ")
email_cliente = input("Ingrese el email del cliente: ")

cliente = Cliente(id_cliente, nombre_cliente, email_cliente)

# Crear venta y agregar productos
venta = Venta(cliente, [])
while True:
    codigo_producto = input("Ingrese el código del producto a vender (o presione Enter para finalizar): ")
    if not codigo_producto:
        break
    cantidad = int(input("Ingrese la cantidad a vender: "))
    venta.agregar_producto(producto, cantidad)

# Mostrar detalles de la venta
print("\nDetalles de la Venta:")
print(venta)
