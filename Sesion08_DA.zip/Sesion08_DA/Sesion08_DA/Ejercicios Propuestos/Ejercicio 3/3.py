import os

# Ruta del archivo que deseas verificar
archivo_a_verificar = "test.txt"

# Comprueba si el archivo existe
if os.path.exists(archivo_a_verificar):
    print(f"El archivo '{archivo_a_verificar}' existe.")
else:
    print(f"El archivo '{archivo_a_verificar}' no existe.")
