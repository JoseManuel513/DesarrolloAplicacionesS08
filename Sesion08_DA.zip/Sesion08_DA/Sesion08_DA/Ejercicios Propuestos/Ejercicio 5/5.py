def buscar_palabra_en_archivo(archivo, palabra_a_buscar):
    try:
        with open(archivo, "r") as file:
            for linea in file:
                if palabra_a_buscar in linea:
                    print(f"La palabra '{palabra_a_buscar}' se encontró en el archivo.")
                    return
        
        print(f"La palabra '{palabra_a_buscar}' no se encontró en el archivo.")
    except FileNotFoundError:
        print(f"El archivo '{archivo}' no se encontró.")

# Nombre del archivo de texto que deseas buscar
nombre_archivo = "mi_archivo.txt"

# Palabra que deseas buscar en el archivo
palabra_a_buscar = "palabra_a_buscar"

# Llama a la función para buscar la palabra en el archivo
buscar_palabra_en_archivo(nombre_archivo, palabra_a_buscar)
