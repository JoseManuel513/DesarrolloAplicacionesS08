#a) INSTRUCCIONES CONDICIONALES
# Inicializa variables
numero_mayor = float('-inf')
numero_menor = float('inf')
suma_numeros = 0

# Captura de los 6 números
for i in range(6):
    numero = float(input(f"Ingrese el número {i + 1}: "))
    suma_numeros += numero
    if numero > numero_mayor:
        numero_mayor = numero
    if numero < numero_menor:
        numero_menor = numero

punto_medio = suma_numeros / 6

# Encuentra el número más cercano al punto medio
numero_cercano = min((numero_menor, numero_mayor), key=lambda x: abs(x - punto_medio))

# Imprime los resultados
print(f"El número mayor es: {numero_mayor}")
print(f"El número menor es: {numero_menor}")
print(f"El número más cercano al punto medio ({punto_medio}) es: {numero_cercano}")

