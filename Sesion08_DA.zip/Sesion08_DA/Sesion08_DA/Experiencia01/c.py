#c) INSTRUCCIONES COLECCIONES

def calcular_suma_promedio(numeros):
    suma = sum(numeros)
    promedio = suma / len(numeros)
    return suma, promedio

# Ejemplo de uso
lista_numeros = [10, 20, 30, 40, 50]
suma, promedio = calcular_suma_promedio(lista_numeros)
print(f"La suma de los números es {suma} y el promedio es {promedio}")
