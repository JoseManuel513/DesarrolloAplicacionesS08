
def file_read(fname):
    with open(fname, "w") as myfile:
        myfile.write("Ejercicios Python\n")
        myfile.write("Ejercicios Java")
    txt = open(fname)
    print(txt.read())
file_read('abc.txt')


"""""
1. Define una función llamada file_read que toma un parámetro fname, que se supone es el nombre de un archivo.
2. Abre el archivo especificado en modo de escritura ("w").
3. Escribe dos líneas de texto en el archivo, "Ejercicios Python" y "Ejercicios Java".
4. Cierra el archivo.
5. Abre nuevamente el archivo en modo de lectura ("r").
6. Lee y muestra el contenido completo del archivo.

"""""


