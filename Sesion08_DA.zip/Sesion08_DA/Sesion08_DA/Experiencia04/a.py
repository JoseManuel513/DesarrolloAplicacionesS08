# 1. Especifica el nombre del archivo y el modo de apertura (texto o binario).
nombre_archivo = "archivo_texto.txt"
modo_apertura = "w"  # "w" para archivo de texto, "wb" para archivo binario

# 2. Abre el archivo en el modo deseado.
with open(nombre_archivo, modo_apertura) as archivo:
    # 3. Utiliza un bucle para escribir contenido línea por línea en el archivo.
    while True:
        linea = input("Ingrese una línea de texto (o 'fin' para terminar): ")
        
        # 4. Define un mecanismo que detenga el bucle cuando sea necesario.
        if linea.lower() == 'fin':
            break
        
        archivo.write(linea + "\n")  # Escribe la línea en el archivo.

# 5. Cierra el archivo una vez hayas terminado de escribir.
print(f"El archivo '{nombre_archivo}' ha sido creado y las líneas han sido escritas.")
