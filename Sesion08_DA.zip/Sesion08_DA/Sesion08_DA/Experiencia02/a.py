# 1. Elaborar Funciones que reciban diccionarios como parámetros para procesar Datos.
#Calcula la suma de los valores en un diccionario.
def suma_valores(diccionario):
    suma = sum(diccionario.values())
    return suma

# 2. Agregar Funciones con parámetros por defecto.
# Calcula la suma de los valores en un diccionario multiplicada por un factor opcional.
def suma_con_factor(diccionario, factor=1):
    suma = sum(diccionario.values())
    return suma * factor

# 3. Agregar Funciones que te devuelvan más de un valor de retorno.
#Calcula la suma y el promedio de los valores en un diccionario.
def suma_promedio(diccionario):
    suma = sum(diccionario.values())
    promedio = suma / len(diccionario)
    return suma, promedio

# Ejemplo de uso:
datos = {"A": 10, "B": 20, "C": 30}

# Llamada a la función 1
suma = suma_valores(datos)
print(f"La suma de valores es {suma}")

# Llamada a la función 2 con factor opcional
suma_factor = suma_con_factor(datos, 2)
print(f"La suma de valores multiplicada por 2 es {suma_factor}")

# Llamada a la función 3 que devuelve dos valores
suma, promedio = suma_promedio(datos)
print(f"La suma de valores es {suma} y el promedio es {promedio}")
