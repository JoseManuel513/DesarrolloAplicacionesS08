import sqlite3

# Establecer una conexión a la base de datos 'orders.db'
conn = sqlite3.connect('orders.db')

# Imprimir un mensaje para confirmar que la base de datos se abrió con éxito
print("Base de datos abierta satisfactoriamente")

# Ejecutar una consulta SQL para actualizar el campo 'TOTAL' en la tabla 'ORDERS'
conn.execute("UPDATE ORDERS SET TOTAL = 25000.00 WHERE ORDERID = 1")

# Confirmar los cambios realizados en la base de datos
conn.commit()

# Imprimir el número total de registros actualizados
print("Número total de registros actualizados:", conn.total_changes)

# Ejecutar una consulta SQL para seleccionar los campos 'ORDERID', 'DATE', 'USERID' y 'TOTAL' de la tabla 'ORDERS'
cursor = conn.execute("SELECT ORDERID, DATE, USERID, TOTAL FROM ORDERS")

# Recorrer los resultados e imprimirlos
for row in cursor:
    print("ORDERID =", row[0])
    print("DATE =", row[1])
    print("USERID =", row[2])
    print("TOTAL =", row[3], "\n")

# Imprimir un mensaje para confirmar que la operación se realizó satisfactoriamente
print("Actualización realizada satisfactoriamente")

# Cerrar la conexión a la base de datos
conn.close()
