import sqlite3

# Establecer una conexión a la base de datos 'orders.db'
conn = sqlite3.connect('orders.db')

# Crear un objeto cursor para ejecutar consultas SQL
cur = conn.cursor()

# Crear la tabla 'ORDERS' si no existe
cur.execute("""
CREATE TABLE IF NOT EXISTS ORDERS (
    ORDERID INT,
    DATE TEXT,
    USERID INT,
    TOTAL REAL
    );
""")

# Imprimir un mensaje para confirmar que la base de datos se abrió con éxito
print("Base de datos abierta satisfactoriamente")

# Insertar registros en la tabla 'ORDERS'
cur.execute("INSERT INTO ORDERS (ORDERID, DATE, USERID, TOTAL) VALUES (1, '02/12/2021', 1, 20000)")
cur.execute("INSERT INTO ORDERS (ORDERID, DATE, USERID, TOTAL) VALUES (2, '02/10/2021', 2, 210)")
cur.execute("INSERT INTO ORDERS (ORDERID, DATE, USERID, TOTAL) VALUES (3, '04/12/2019', 3, 415203)")
cur.execute("INSERT INTO ORDERS (ORDERID, DATE, USERID, TOTAL) VALUES (4, '02/09/2019', 4, 2541360)")

# Confirmar los cambios realizados en la base de datos
conn.commit()

# Imprimir un mensaje para confirmar que los registros se crearon satisfactoriamente
print("Registros creados satisfactoriamente")

# Ejecutar una consulta SQL para seleccionar todos los registros de la tabla 'ORDERS'
cur.execute("SELECT * FROM ORDERS")

# Recorrer los resultados e imprimirlos
for row in cur.fetchall():
    print("ORDERID =", row[0])
    print("DATE =", row[1])
    print("USERID =", row[2])
    print("TOTAL =", row[3], "\n")

# Cerrar la conexión a la base de datos
conn.close()
