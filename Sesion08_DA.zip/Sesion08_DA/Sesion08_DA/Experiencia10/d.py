import sqlite3

# Establecer una conexión a la base de datos 'orders.db'
conn = sqlite3.connect('orders.db')

# Imprimir un mensaje para confirmar que la base de datos se abrió con éxito
print("Base de datos abierta satisfactoriamente")

# Ejecutar una consulta SQL para eliminar el registro donde 'ORDERID' es igual a 2
conn.execute("DELETE FROM ORDERS WHERE ORDERID = 2")

# Confirmar los cambios realizados en la base de datos
conn.commit()

# Imprimir el número total de registros borrados
print("Número total de registros borrados:", conn.total_changes)

# Ejecutar una consulta SQL para seleccionar los campos 'ORDERID', 'DATE', 'USERID' y 'TOTAL' de la tabla 'ORDERS'
cursor = conn.execute("SELECT ORDERID, DATE, USERID, TOTAL FROM ORDERS")

# Recorrer los resultados e imprimirlos
for row in cursor:
    print("ORDERID =", row[0])
    print("DATE =", row[1])
    print("USERID =", row[2])
    print("TOTAL =", row[3], "\n")

# Imprimir un mensaje para confirmar que la operación se realizó satisfactoriamente
print("Eliminación realizada satisfactoriamente")

# Cerrar la conexión a la base de datos
conn.close()
