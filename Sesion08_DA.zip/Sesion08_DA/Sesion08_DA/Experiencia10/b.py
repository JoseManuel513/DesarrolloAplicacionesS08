import sqlite3

# Establecer una conexión a la base de datos 'orders.db'
conn = sqlite3.connect('orders.db')

# Imprimir un mensaje para confirmar que la base de datos se abrió con éxito
print("Base de datos abierta satisfactoriamente")

# Ejecutar una consulta SQL para seleccionar los campos 'ORDERID', 'DATE', 'USERID' y 'TOTAL' de la tabla 'ORDERS'
cursor = conn.execute("SELECT ORDERID, DATE, USERID, TOTAL from ORDERS")

# Recorrer los resultados e imprimirlos
for row in cursor:
    print("ORDERID =", row[0])
    print("DATE =", row[1])
    print("USERID =", row[2])
    print("TOTAL =", row[3], "\n")

# Imprimir un mensaje para confirmar que la operación se realizó satisfactoriamente
print("Operación realizada satisfactoriamente")

# Cerrar la conexión a la base de datos
conn.close()